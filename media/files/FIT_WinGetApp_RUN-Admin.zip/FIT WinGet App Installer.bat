@echo off
TITLE Interactive Queue Installer

:: Use PowerShell to set console colors and window sizing
powershell -Command "$c = Get-Host.UI.RawUI; $s = $c.BufferSize; $s.Width = 140; $s.Height = 50; $c.BufferSize = $s; $f = $c.WindowSize; $f.Width = 140; $f.Height = 50; $c.WindowSize = $f; $host.ui.rawui.BackgroundColor = [System.ConsoleColor]::Yellow; $host.ui.rawui.ForegroundColor = [System.ConsoleColor]::Black; Clear-Host"

:: Force-inject TrueType font size 28 (0x001C0000 -> 1835008 decimal) and bold weight (FontWeight = 700) into the Windows Registry profile
powershell -Command "$regPath = 'HKCU:\Console'; $paths = Get-ChildItem $regPath | Where-Object {$_.PSChildName -match 'cmd\.exe|_system32_cmd\.exe'}; foreach($p in $paths) { Set-ItemProperty -Path $p.PSPath -Name 'FontSize' -Value 1835008 -ErrorAction SilentlyContinue; Set-ItemProperty -Path $p.PSPath -Name 'FontWeight' -Value 700 -ErrorAction SilentlyContinue }; $defaultPath = 'HKCU:\Console'; if(Test-Path $defaultPath) { Set-ItemProperty -Path $defaultPath -Name 'FontSize' -Value 1835008 -ErrorAction SilentlyContinue; Set-ItemProperty -Path $defaultPath -Name 'FontWeight' -Value 700 -ErrorAction SilentlyContinue }" >nul 2>&1

echo.
echo.
echo =========================================================================================
echo                     Francis IT - Winget Installation of Apps     Built:  June 2026
echo =========================================================================================
echo.
echo.
echo.
:: Single-keypress prompts using the CHOICE command with a 10-space left indent and added empty lines
echo.
choice /c YN /n /m "          Install Microsoft PC Manager? (Y/N): "
set "run_pcman=%errorlevel%"

echo.
choice /c YN /n /m "          Install WinToys? (Y/N): "
set "run_wintoys=%errorlevel%"

echo.
choice /c YN /n /m "          Install Google Chrome? (Y/N): "
set "run_chrome=%errorlevel%"

echo.
choice /c YN /n /m "          Install Mozilla Firefox? (Y/N): "
set "run_firefox=%errorlevel%"

echo.
choice /c YN /n /m "          Install LibreOffice? (Y/N): "
set "run_libre=%errorlevel%"

echo.
choice /c YN /n /m "          Install Revo Uninstaller? (Y/N): "
set "run_revo=%errorlevel%"

echo.
choice /c YN /n /m "          Install Malwarebytes? (Y/N): "
set "run_mb=%errorlevel%"

echo.
choice /c YN /n /m "          Install 7-Zip? (Y/N): "
set "run_7zip=%errorlevel%"

echo.
choice /c YN /n /m "          Install Everything? (Y/N): "
set "run_every=%errorlevel%"

echo.
choice /c YN /n /m "          Install VLC Media Player? (Y/N): "
set "run_vlc=%errorlevel%"

echo.
choice /c YN /n /m "          Install IrfanView? (Y/N): "
set "run_irfan=%errorlevel%"

echo.
choice /c YN /n /m "          Install Adobe Acrobat Reader 64-bit? (Y/N): "
set "run_adobe=%errorlevel%"

echo.
choice /c YN /n /m "          Install SumatraPDF? (Y/N): "
set "run_sumatra=%errorlevel%"

echo.
choice /c YN /n /m "          Install Zoom Workplace? (Y/N): "
set "run_zoom=%errorlevel%"

echo.
choice /c YN /n /m "          Install Spotify? (Y/N): "
set "run_spotify=%errorlevel%"

echo.
choice /c YN /n /m "          Install AutoHotkey? (Y/N): "
set "run_ahk=%errorlevel%"

echo.
choice /c YN /n /m "          Restart computer upon completion? (Y/N): "
set "run_restart=%errorlevel%"

echo.
echo ==================================================================
echo.
echo                   Updating Winget Sources .....
echo.
echo ==================================================================
winget source update

echo.
echo.
echo.
echo ==================================================================
echo.
echo                      Executing Installation Queue...
echo.
echo ==================================================================
echo.
echo.

if "%run_pcman%"=="1" winget install --id=Microsoft.PCManager -e --accept-package-agreements --accept-source-agreements
if "%run_wintoys%"=="1" winget install --id=9P8LTPGCBZXD -s msstore --accept-package-agreements --accept-source-agreements
if "%run_chrome%"=="1" winget install --id=Google.Chrome -e --accept-package-agreements --accept-source-agreements
if "%run_firefox%"=="1" winget install --id=Mozilla.Firefox -e --accept-package-agreements --accept-source-agreements
if "%run_libre%"=="1" winget install --id=TheDocumentFoundation.LibreOffice -e --accept-package-agreements --accept-source-agreements
if "%run_revo%"=="1" winget install --id=VSecter.RevoUninstaller -e --accept-package-agreements --accept-source-agreements
if "%run_mb%"=="1" winget install --id=Malwarebytes.Malwarebytes -e --accept-package-agreements --accept-source-agreements
if "%run_7zip%"=="1" winget install --id=7zip.7zip -e --accept-package-agreements --accept-source-agreements
if "%run_every%"=="1" winget install --id=voidtools.Everything -e --accept-package-agreements --accept-source-agreements
if "%run_vlc%"=="1" winget install --id=VideoLAN.VLC -e --accept-package-agreements --accept-source-agreements
if "%run_irfan%"=="1" winget install --id=IrfanSkiljan.IrfanView -e --accept-package-agreements --accept-source-agreements
if "%run_adobe%"=="1" winget install --id=Adobe.Acrobat.Reader.64-bit -e --accept-package-agreements --accept-source-agreements
if "%run_sumatra%"=="1" winget install --id=SumatraPDF.SumatraPDF -e --accept-package-agreements --accept-source-agreements
if "%run_zoom%"=="1" winget install --id=Zoom.Zoom -e --accept-package-agreements --accept-source-agreements
if "%run_spotify%"=="1" winget install --id=Spotify.Spotify -e --accept-package-agreements --accept-source-agreements
if "%run_ahk%"=="1" winget install --id=Lexikos.AutoHotkey -e --accept-package-agreements --accept-source-agreements

echo.
echo.
echo ==================================================================
echo.
echo                        Queue Processing Finished.
echo.
echo ==================================================================
echo.
echo.

if "%run_restart%"=="1" (
    echo Restarting system in 10 seconds...
    shutdown /r /t 10 /c "Automated restart triggered by batch installer."
) else (
  echo.
  echo.
  echo.
  echo ==================================================================
  echo.
  echo                       All tasks completed. 
  echo.
  echo.
  echo                       Press any key to exit.
  echo.
  echo ==================================================================
  echo.
  echo.
  echo. 
  echo.
  echo.
    pause >nul
)